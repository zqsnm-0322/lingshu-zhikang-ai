create
    definer = root@localhost procedure add_tomorrow_food(IN p_name varchar(100), IN p_category varchar(50),
                                                         IN p_description text, IN p_price decimal(10, 2),
                                                         IN p_calories int, IN p_image_url varchar(255),
                                                         IN p_is_vegetarian tinyint(1))
BEGIN
  INSERT INTO `daily_food` (
    `name`, 
    `category`, 
    `description`, 
    `price`, 
    `calories`, 
    `recommend_date`, 
    `image_url`, 
    `is_vegetarian`
  ) VALUES (
    p_name, 
    p_category, 
    p_description, 
    p_price, 
    p_calories, 
    DATE_ADD(CURDATE(), INTERVAL 1 DAY), 
    p_image_url, 
    p_is_vegetarian
  );
END;

