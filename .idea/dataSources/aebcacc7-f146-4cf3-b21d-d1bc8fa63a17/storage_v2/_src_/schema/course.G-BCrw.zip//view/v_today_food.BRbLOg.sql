create definer = root@localhost view v_today_food as
select `course`.`daily_food`.`id`             AS `id`,
       `course`.`daily_food`.`name`           AS `name`,
       `course`.`daily_food`.`category`       AS `category`,
       `course`.`daily_food`.`description`    AS `description`,
       `course`.`daily_food`.`price`          AS `price`,
       `course`.`daily_food`.`calories`       AS `calories`,
       `course`.`daily_food`.`recommend_date` AS `recommend_date`,
       `course`.`daily_food`.`image_url`      AS `image_url`,
       `course`.`daily_food`.`is_vegetarian`  AS `is_vegetarian`
from `course`.`daily_food`
where (`course`.`daily_food`.`recommend_date` = curdate());

-- comment on column v_today_food.id not supported: 主键

-- comment on column v_today_food.name not supported: 美食名称

-- comment on column v_today_food.category not supported: 分类：早餐、午餐、晚餐、小吃、甜点

-- comment on column v_today_food.description not supported: 美食描述

-- comment on column v_today_food.price not supported: 价格

-- comment on column v_today_food.calories not supported: 卡路里

-- comment on column v_today_food.recommend_date not supported: 推荐日期

-- comment on column v_today_food.image_url not supported: 图片链接

-- comment on column v_today_food.is_vegetarian not supported: 是否素食：0-否，1-是

