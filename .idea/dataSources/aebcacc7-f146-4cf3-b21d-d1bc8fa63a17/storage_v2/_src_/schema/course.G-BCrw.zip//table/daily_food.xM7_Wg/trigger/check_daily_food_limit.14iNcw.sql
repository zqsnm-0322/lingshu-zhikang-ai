create definer = root@localhost trigger check_daily_food_limit
    before insert
    on daily_food
    for each row
BEGIN
  DECLARE food_count INT;
  
  SELECT COUNT(*) INTO food_count 
  FROM `daily_food` 
  WHERE `recommend_date` = NEW.recommend_date;
  
  IF food_count >= 10 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = '每天最多只能有10个推荐美食';
  END IF;
END;

